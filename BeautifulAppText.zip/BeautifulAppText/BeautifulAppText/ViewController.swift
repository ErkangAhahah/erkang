//
//  ViewController.swift
//  BeautifulAppText
//
//  Created by 全世界最美丽的尔康 on 2018/11/14.
//  Copyright © 2018年 全世界最美丽的尔康. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

